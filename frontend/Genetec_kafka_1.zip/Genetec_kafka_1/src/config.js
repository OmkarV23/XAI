// config.js
export const ARG1 = 'node';
export const ARG2 = 'consumer.js';
export const ARG3 = 'C:\Users\rithi\OneDrive\Desktop\React projects\cameraMap.json';
